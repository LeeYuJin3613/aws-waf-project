region              = "ap-northeast-2"
project_name        = "netid"
vpc_cidr            = "172.16.0.0/16"
azs                 = ["ap-northeast-2a", "ap-northeast-2c"]
public_key_material = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCaHOzqjKsJyJUgZPuZ2tDY1IpNebiSFW8zHxd9hGtXDOt2202eQ5WFn7V8TDcYXXnXnITi1PldJGADWVVOY0BMZKTJnatjtjMvR5h/kJuwZ74TpqsNjmbSZSBMdKHVTcePg2shryfHoaUUbCCAwCg1KyTRMwNKRja+UCtK0L3/B2pmMjzvOthzWDYUkVeNuaIntY3DbXwShgxa7DlKX6Tl3GY+j+gve0FiqVOeIndhKx5uGkDTt7XaXv8sA8ZiGpGF3DpGlUiwPzHfepNQ9DEI8eHx9GsYDNfHNaklShFrM3Eki09gNOXApNMKomrbe3ZNoo9yjXOWy4caIxkblgNn rsa-key-20261111"
web_ami             = "ami-0131b10cfa2943e15"
openvpn_ami         = "ami-0f42c79eb0c2339c9"
db_name             = "webDB"
user_name           = "root"
db_instance_class   = "db.t3.micro"
db_engine_version   = "8.4.11"
user_data           = <<-EOT
  #!/bin/bash
  yum install -y httpd php php-mbstring php-pdo php-mysqlnd php-gd wget unzip
  wget -O /tmp/frontend_source.zip https://github.com/LeeYuJin3613/aws-waf-project/raw/refs/heads/main/frontend_source.zip
  unzip -o /tmp/frontend_source.zip -d /var/www/html/
  systemctl start httpd & systemctl enable httpd
  EOT
